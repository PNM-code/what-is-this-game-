#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

#include<iostream>
#include<ctime>
#include <stdlib.h>
#include <stdio.h>
#include<cstring>
#include <cstdlib> // for rand() and srand()
#include <cmath>


#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480

long long i,j,k;

int time_start_run_code=clock();

using namespace std;

// return fps game: but it is bugging
static float fps(){
    static int a=clock();
    float fps=(float)CLOCKS_PER_SEC/(clock()-a);
    a=clock();
    return fps;
}
static float fps(int x){
    static int fam=15;//15 is load time
    fam++;
    //return (clock()-time_start_run_code)/CLOCKS_PER_SEC;
    return (float)fam/(clock()-time_start_run_code)*CLOCKS_PER_SEC;
}

// Function for loading font and drawing text into SDL_Texture
static SDL_Texture *loadText(SDL_Renderer *renderer, const char *text)
{
	if (TTF_Init() == -1)
	{
		fprintf(stderr, "TTF_Init Error: %s\n", TTF_GetError());
		return NULL;
	}
	TTF_Font *font = TTF_OpenFont("/system/fonts/Roboto-Regular.ttf", 256);
	if (font == NULL)
	{
		fprintf(stderr, "TTF_OpenFont Error: %s\n", TTF_GetError());
		return NULL;
	}
	SDL_Color color = {90, 90, 90};
	SDL_Surface *surface = TTF_RenderText_Solid(font, text, color);
	SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
	SDL_FreeSurface(surface);
	if (texture == NULL)
	{
		fprintf(stderr, "SDL_CreateTextureFromSurface Error: %s\n", SDL_GetError());
		return NULL;
	}
	return texture;
}

static SDL_Texture *loadImage(SDL_Renderer *renderer, const char *path)
{
	SDL_Surface *img = IMG_Load(path);
	if (img == NULL)
	{
		fprintf(stderr, "IMG_Load Error: %s\n", IMG_GetError());
		return NULL;
	}
	SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, img);
	SDL_FreeSurface(img);
	if (texture == NULL)
	{
		fprintf(stderr, "SDL_CreateTextureFromSurface Error: %s\n", SDL_GetError());
		return NULL;
	}
	return texture;
}

int main(int argc, char *argv[])
{
	srand(time(0));
	if (SDL_Init(SDL_INIT_EVERYTHING) != 0)
	{
		fprintf(stderr, "SDL_Init Error: %s\n", SDL_GetError());
		return 1;
	}
	SDL_Window *window = SDL_CreateWindow("Hello SDL2-ttf", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 640, 480, 0);
	if (window == NULL)
	{
		fprintf(stderr, "SDL_CreateWindow Error: %s\n", SDL_GetError());
		return 1;
	}

	SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, 0);
	if (renderer == NULL)
	{
		fprintf(stderr, "SDL_CreateRenderer Error: %s\n", SDL_GetError());
		return 1;
	}
	// Better scaling quality
 	SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "2");
	SDL_Texture *textTexture[] = {
	   loadText(renderer, " "),
	   loadText(renderer, "!"),
	   loadText(renderer, "\""),
	   loadText(renderer, "#"),
	   loadText(renderer, "$"),
	   loadText(renderer, "%"),
	   loadText(renderer, "&"),
	   loadText(renderer, "'"),
	   loadText(renderer, "("),
	   loadText(renderer, ")"),
	   loadText(renderer, "*"),
	   loadText(renderer, "+"),
	   loadText(renderer, ","),
	   loadText(renderer, "-"),
	   loadText(renderer, "."),
	   loadText(renderer, "/"),
	   loadText(renderer, "0"),
	   loadText(renderer, "1"),
	   loadText(renderer, "2"),
	   loadText(renderer, "3"),
	   loadText(renderer, "4"),
	   loadText(renderer, "5"),
	   loadText(renderer, "6"),
	   loadText(renderer, "7"),
	   loadText(renderer, "8"),
	   loadText(renderer, "9")
	};
	for (SDL_Texture *i:textTexture)
	if(i == NULL)
	{
		fprintf(stderr, "Couldn't load text texture\n");
		return 1;
	}
	// img
	SDL_Texture *imageTexture = loadImage(renderer, "a.png");
	if (imageTexture == NULL)
	{
		fprintf(stderr, "Couldn't load image\n");
		return 1;
	}
	SDL_Texture *img_ball = loadImage(renderer, "easter_egg.png");
	if (img_ball == NULL)
	{
		fprintf(stderr, "Couldn't load image\n");
		return 1;
	}
	SDL_Texture *img_f = loadImage(renderer, "ball_reb.png");	if (img_f == NULL)
	{
		fprintf(stderr, "Couldn't load image\n");
		return 1;
	}
	int tw, th;
	SDL_QueryTexture(*textTexture, NULL, NULL, &tw, &th);
	int w, h;
	SDL_GetRendererOutputSize(renderer, &w, &h);
	SDL_Rect dest;
	SDL_Event ev;
	
	SDL_Rect destPlayer;
	destPlayer.x=0;
   destPlayer.y=0;
	destPlayer.w=64;
   destPlayer.h=64;
   SDL_Rect destF;
	destF.w=64;
   destF.h=64;
   destF.x=rand()%500;
	destF.y=rand()%500;
	SDL_Rect destImg;
	SDL_Rect destScreen;
	destScreen.x=0;
	destScreen.y=0;
	
	double xp=0,
	         yp=0;
	while(true){
   //test
   SDL_MultiGestureEvent Event;
   while(SDL_PollEvent(&ev))
      switch(ev.type){
       // case SDL_MultiGestureEvent:
         //case SDL_MULTIGESTURE: break
         //SDL_TouchFingerEvent
         case SDL_FINGERMOTION:
             destScreen.x-=ev.tfinger.dx*700;
             destScreen.y-=ev.tfinger.dy*12000;
      }
	//clear
	SDL_RenderClear(renderer);
	const int speedPlayer= 10;// pixel
   double tl=sqrt(pow(abs(destScreen.y-yp),2)+pow(abs(destScreen.x-xp),2))/speedPlayer;
   if (tl>1){
      xp+=(long double)(destScreen.x-xp)/tl;
   
      yp+=(long double)(destScreen.y-yp)/tl;
   }
	destPlayer.x=xp+700/2-destScreen.x-destPlayer.w/2;
   destPlayer.y=yp+1200/2-destScreen.y-destPlayer.h/2;
   
	destImg.w=32;
	destImg.h=32;
	for(i=-destScreen.y;i<=SCREEN_HEIGHT +770-destScreen.y ;i+=32)
	   for(j=-destScreen.x;j<=SCREEN_WIDTH +70-destScreen.x;j+=32 ){
	       destImg.x=j;
	       destImg.y=i;
          SDL_RenderCopy(renderer, imageTexture, NULL, &destImg);
	}
	// Our text always has width much bigger than height, use this

   int x1 =destPlayer.x;
   int y1 =destPlayer.y;
   int h1 =destPlayer.h;
   int w1 =destPlayer.w;
   
   int x2 =destF.x;
   int y2 =destF.y;
   int h2 =destF.h;
   int w2 =destF.w;
   static int rand1,rand2;
	if((x1+w1 >= x2) && (x2+w2 >= x1) && (y1+w1 >= y2) && (y2+w2 >= y1)){
	rand1=rand()%500;
	rand2=rand()%500;
	
	destPlayer.w+=10-destPlayer.w*0.01;
	destPlayer.h+=10-destPlayer.h*0.01;
	}
	destF.x=rand1-destScreen.x;
	destF.y=abs(rand2)-destScreen.y;
	
	SDL_RenderCopy(renderer, img_f, NULL, &destF);
	SDL_RenderCopy(renderer, img_ball, NULL, &destPlayer);
		dest.x = 0;
	w=20;
	dest.w = w;
	dest.h = th * w / tw;
	//dest.y = (h - dest.h) / 2;
	dest.y=1;
	string num=to_string(fps(0));
	for(int i=0;i<num.size();i++,dest.x+=22){
	SDL_RenderCopy(renderer, textTexture[num[i]-' '], NULL, &dest);
	}
	SDL_RenderPresent(renderer);
	//SDL_Delay(20);
	}
	SDL_DestroyWindow(window);
	SDL_Quit();
	return 0;
}
